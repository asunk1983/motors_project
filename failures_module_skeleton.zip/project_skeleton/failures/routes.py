from datetime import datetime

from flask import Blueprint, render_template, request, redirect, url_for
from sqlalchemy import func, or_

from extensions import db
from failures.models import (
    EquipmentType, Component, Symptom, Cause, RemediationMethod,
    Case, DiagnosticStep, Tag,
)

failures_bp = Blueprint(
    "failures", __name__, template_folder="templates"
)


@failures_bp.route("/")
def index():
    cases = Case.query.order_by(Case.date_reported.desc()).limit(50).all()
    return render_template("failures/index.html", cases=cases)


@failures_bp.route("/cases/new", methods=["GET", "POST"])
def new_case():
    if request.method == "POST":
        case = Case(
            equipment_type_id=request.form["equipment_type_id"],
            symptom_id=request.form["symptom_id"],
            equipment_ref_code=request.form.get("equipment_ref_code"),
            notes=request.form.get("notes"),
        )
        db.session.add(case)
        db.session.commit()
        return redirect(url_for("failures.case_detail", case_id=case.id))

    equipment_types = EquipmentType.query.all()
    symptoms = Symptom.query.all()
    return render_template(
        "failures/new_case.html",
        equipment_types=equipment_types,
        symptoms=symptoms,
    )


@failures_bp.route("/cases/<int:case_id>")
def case_detail(case_id):
    case = Case.query.get_or_404(case_id)
    components = Component.query.all()
    causes = Cause.query.all()
    remediations = RemediationMethod.query.all()
    return render_template(
        "failures/case_detail.html",
        case=case,
        components=components,
        causes=causes,
        remediations=remediations,
    )


@failures_bp.route("/cases/<int:case_id>/steps", methods=["POST"])
def add_diagnostic_step(case_id):
    case = Case.query.get_or_404(case_id)
    next_order = len(case.diagnostic_steps) + 1
    step = DiagnosticStep(
        case_id=case.id,
        component_id=request.form["component_id"],
        order_index=next_order,
        result_ok=(request.form.get("result_ok") == "true"),
        notes=request.form.get("notes"),
    )
    db.session.add(step)
    db.session.commit()
    return redirect(url_for("failures.case_detail", case_id=case.id))


@failures_bp.route("/search")
def search():
    """Поиск случаев по набору фильтров. Все параметры опциональны,
    комбинируются через AND. Свободный текст ищется в notes и в коде
    оборудования."""
    q = Case.query

    text = request.args.get("q", "").strip()
    equipment_type_id = request.args.get("equipment_type_id", type=int)
    symptom_id = request.args.get("symptom_id", type=int)
    cause_id = request.args.get("cause_id", type=int)
    tag_id = request.args.get("tag_id", type=int)
    date_from = request.args.get("date_from")
    date_to = request.args.get("date_to")
    only_unresolved = request.args.get("only_unresolved") == "1"

    if text:
        like = f"%{text}%"
        q = q.filter(or_(Case.notes.ilike(like), Case.equipment_ref_code.ilike(like)))
    if equipment_type_id:
        q = q.filter(Case.equipment_type_id == equipment_type_id)
    if symptom_id:
        q = q.filter(Case.symptom_id == symptom_id)
    if cause_id:
        q = q.filter(Case.cause_id == cause_id)
    if tag_id:
        q = q.filter(Case.tags.any(Tag.id == tag_id))
    if date_from:
        q = q.filter(Case.date_reported >= datetime.fromisoformat(date_from))
    if date_to:
        q = q.filter(Case.date_reported <= datetime.fromisoformat(date_to))
    if only_unresolved:
        q = q.filter(Case.cause_id.is_(None))

    results = q.order_by(Case.date_reported.desc()).limit(200).all()

    return render_template(
        "failures/search.html",
        results=results,
        equipment_types=EquipmentType.query.all(),
        symptoms=Symptom.query.all(),
        causes=Cause.query.all(),
        tags=Tag.query.all(),
        filters=request.args,
    )


@failures_bp.route("/statistics")
def statistics():
    total_cases = db.session.query(func.count(Case.id)).scalar() or 0
    unresolved_cases = db.session.query(func.count(Case.id)).filter(Case.cause_id.is_(None)).scalar() or 0
    resolved_cases = total_cases - unresolved_cases

    avg_downtime = db.session.query(func.avg(Case.downtime_hours)).scalar()
    total_cost = db.session.query(func.sum(Case.cost)).scalar()

    # Среднее время устранения (от регистрации до закрытия), в часах
    resolved_with_dates = (
        db.session.query(Case.date_reported, Case.date_resolved)
        .filter(Case.date_resolved.isnot(None))
        .all()
    )
    if resolved_with_dates:
        deltas = [
            (resolved - reported).total_seconds() / 3600
            for reported, resolved in resolved_with_dates
        ]
        avg_resolution_hours = sum(deltas) / len(deltas)
    else:
        avg_resolution_hours = None

    # Топ причин по частоте
    top_causes = (
        db.session.query(Cause.name, func.count(Case.id).label("cnt"))
        .join(Case, Case.cause_id == Cause.id)
        .group_by(Cause.id)
        .order_by(func.count(Case.id).desc())
        .limit(10)
        .all()
    )

    # Топ типов оборудования по количеству случаев
    top_equipment = (
        db.session.query(EquipmentType.name, func.count(Case.id).label("cnt"))
        .join(Case, Case.equipment_type_id == EquipmentType.id)
        .group_by(EquipmentType.id)
        .order_by(func.count(Case.id).desc())
        .limit(10)
        .all()
    )

    # Среднее время простоя по типу оборудования
    avg_downtime_by_equipment = (
        db.session.query(EquipmentType.name, func.avg(Case.downtime_hours))
        .join(Case, Case.equipment_type_id == EquipmentType.id)
        .group_by(EquipmentType.id)
        .all()
    )

    # Компоненты, которые чаще всего оказываются реальной причиной
    # (шаг диагностики с result_ok = False)
    top_faulty_components = (
        db.session.query(Component.name, func.count(DiagnosticStep.id).label("cnt"))
        .join(DiagnosticStep, DiagnosticStep.component_id == Component.id)
        .filter(DiagnosticStep.result_ok.is_(False))
        .group_by(Component.id)
        .order_by(func.count(DiagnosticStep.id).desc())
        .limit(10)
        .all()
    )

    # Динамика количества случаев по месяцам (для линейного графика)
    cases_by_month_raw = (
        db.session.query(
            func.strftime("%Y-%m", Case.date_reported).label("month"),
            func.count(Case.id),
        )
        .group_by("month")
        .order_by("month")
        .all()
    )

    return render_template(
        "failures/statistics.html",
        total_cases=total_cases,
        resolved_cases=resolved_cases,
        unresolved_cases=unresolved_cases,
        avg_downtime=avg_downtime,
        avg_resolution_hours=avg_resolution_hours,
        total_cost=total_cost,
        top_causes=top_causes,
        top_equipment=top_equipment,
        avg_downtime_by_equipment=avg_downtime_by_equipment,
        top_faulty_components=top_faulty_components,
        cases_by_month=cases_by_month_raw,
    )


@failures_bp.route("/analytics")
def analytics():
    # Оставлено для обратной совместимости со старыми ссылками/закладками.
    return redirect(url_for("failures.statistics"))
