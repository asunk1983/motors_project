from datetime import datetime

from extensions import db

BIND = "failures"

# ---------------------------------------------------------------------------
# Таблицы связей (многие-ко-многим) должны использовать ту же MetaData,
# что и модели bind'а "failures" — иначе SQLAlchemy не сможет разрешить
# внешние ключи между ними. Используем db._make_metadata(), а не создаём
# MetaData вручную: только этот метод проставляет info={"bind_key": ...},
# по которому Flask-SQLAlchemy маршрутизирует сессию на нужный движок/файл
# БД. Без этого INSERT/SELECT для этих таблиц уходили бы в дефолтную БД.
# ---------------------------------------------------------------------------
_failures_metadata = db._make_metadata(BIND)

symptom_cause_link = db.Table(
    "symptom_cause_link",
    _failures_metadata,
    db.Column("symptom_id", db.Integer, db.ForeignKey("symptom.id"), primary_key=True),
    db.Column("cause_id", db.Integer, db.ForeignKey("cause.id"), primary_key=True),
)

cause_remediation_link = db.Table(
    "cause_remediation_link",
    _failures_metadata,
    db.Column("cause_id", db.Integer, db.ForeignKey("cause.id"), primary_key=True),
    db.Column("remediation_id", db.Integer, db.ForeignKey("remediation_method.id"), primary_key=True),
)

case_tag_link = db.Table(
    "case_tag_link",
    _failures_metadata,
    db.Column("case_id", db.Integer, db.ForeignKey("case.id"), primary_key=True),
    db.Column("tag_id", db.Integer, db.ForeignKey("tag.id"), primary_key=True),
)


class EquipmentType(db.Model):
    """Тип оборудования: нагреватель, пускатель, насос, двигатель и т.д."""
    __bind_key__ = BIND
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False, unique=True)
    description = db.Column(db.Text)

    cases = db.relationship("Case", back_populates="equipment_type")

    def __repr__(self):
        return f"<EquipmentType {self.name}>"


class Component(db.Model):
    """Узел/деталь, который можно проверить в ходе диагностики
    (обмотка, контактор, фаза, датчик температуры...)."""
    __bind_key__ = BIND
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False, unique=True)
    description = db.Column(db.Text)

    diagnostic_steps = db.relationship("DiagnosticStep", back_populates="component")

    def __repr__(self):
        return f"<Component {self.name}>"


class Symptom(db.Model):
    """Внешнее проявление проблемы: 'не работает нагрев', 'не запускается'."""
    __bind_key__ = BIND
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False, unique=True)
    description = db.Column(db.Text)

    typical_causes = db.relationship(
        "Cause", secondary=symptom_cause_link, back_populates="typical_symptoms"
    )
    cases = db.relationship("Case", back_populates="symptom")

    def __repr__(self):
        return f"<Symptom {self.name}>"


class Cause(db.Model):
    """Первопричина: 'отсутствие фазы', 'неисправен пускатель'."""
    __bind_key__ = BIND
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False, unique=True)
    description = db.Column(db.Text)
    # эксплуатационная / конструктивная / производственная / износ
    cause_type = db.Column(db.String(50))

    typical_symptoms = db.relationship(
        "Symptom", secondary=symptom_cause_link, back_populates="typical_causes"
    )
    typical_remediations = db.relationship(
        "RemediationMethod", secondary=cause_remediation_link, back_populates="typical_causes"
    )
    cases = db.relationship("Case", back_populates="cause")

    def __repr__(self):
        return f"<Cause {self.name}>"


class RemediationMethod(db.Model):
    """Способ устранения: замена, ремонт, регулировка."""
    __bind_key__ = BIND
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False, unique=True)
    description = db.Column(db.Text)
    avg_time_hours = db.Column(db.Float)
    required_qualification = db.Column(db.String(120))

    typical_causes = db.relationship(
        "Cause", secondary=cause_remediation_link, back_populates="typical_remediations"
    )
    cases = db.relationship("Case", back_populates="remediation_method")

    def __repr__(self):
        return f"<RemediationMethod {self.name}>"


class Tag(db.Model):
    """Свободные теги для гибкого поиска по случаям."""
    __bind_key__ = BIND
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False, unique=True)

    cases = db.relationship("Case", secondary=case_tag_link, back_populates="tags")


class Case(db.Model):
    """Конкретный зафиксированный случай поломки — основной источник
    аналитики (простой, частота причин, время устранения и т.д.)."""
    __bind_key__ = BIND
    id = db.Column(db.Integer, primary_key=True)

    equipment_type_id = db.Column(db.Integer, db.ForeignKey("equipment_type.id"), nullable=False)
    symptom_id = db.Column(db.Integer, db.ForeignKey("symptom.id"), nullable=False)
    cause_id = db.Column(db.Integer, db.ForeignKey("cause.id"))  # заполняется по итогу диагностики
    remediation_method_id = db.Column(db.Integer, db.ForeignKey("remediation_method.id"))

    # "Мягкая" связь с проектом паспортов — НЕ внешний ключ, т.к. это
    # отдельная база. Просто совпадающее значение (инв. номер / код модели).
    equipment_ref_code = db.Column(db.String(120), index=True)

    date_reported = db.Column(db.DateTime, default=datetime.utcnow)
    date_resolved = db.Column(db.DateTime)
    downtime_hours = db.Column(db.Float)
    cost = db.Column(db.Float)
    notes = db.Column(db.Text)

    equipment_type = db.relationship("EquipmentType", back_populates="cases")
    symptom = db.relationship("Symptom", back_populates="cases")
    cause = db.relationship("Cause", back_populates="cases")
    remediation_method = db.relationship("RemediationMethod", back_populates="cases")
    diagnostic_steps = db.relationship(
        "DiagnosticStep", back_populates="case", order_by="DiagnosticStep.order_index"
    )
    tags = db.relationship("Tag", secondary=case_tag_link, back_populates="cases")

    def __repr__(self):
        return f"<Case #{self.id} eq={self.equipment_ref_code}>"


class DiagnosticStep(db.Model):
    """Шаг диагностики внутри случая: что проверяли и с каким результатом.
    Пример из вашего кейса: шаг 1 — датчик (норма), шаг 2 — пускатель
    (найдена причина: отсутствие фазы)."""
    __bind_key__ = BIND
    id = db.Column(db.Integer, primary_key=True)
    case_id = db.Column(db.Integer, db.ForeignKey("case.id"), nullable=False)
    component_id = db.Column(db.Integer, db.ForeignKey("component.id"), nullable=False)
    order_index = db.Column(db.Integer, nullable=False)
    result_ok = db.Column(db.Boolean)  # True = компонент исправен, False = найдена проблема
    notes = db.Column(db.Text)

    case = db.relationship("Case", back_populates="diagnostic_steps")
    component = db.relationship("Component", back_populates="diagnostic_steps")

    def __repr__(self):
        return f"<DiagnosticStep case={self.case_id} step={self.order_index}>"
