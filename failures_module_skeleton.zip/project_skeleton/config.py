import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
INSTANCE_DIR = os.path.join(BASE_DIR, "instance")

os.makedirs(INSTANCE_DIR, exist_ok=True)


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-change-me")

    # Основная база (используется как "default") — оставляем под существующий
    # проект паспортов, чтобы ничего не пришлось переписывать в нём.
    SQLALCHEMY_DATABASE_URI = "sqlite:///" + os.path.join(INSTANCE_DIR, "passports.db")

    # Вторая, полностью независимая база — знания о поломках оборудования.
    # Никаких foreign key между passports.db и failures.db быть не может,
    # SQLite физически не поддерживает FK между разными файлами БД.
    SQLALCHEMY_BINDS = {
        "failures": "sqlite:///" + os.path.join(INSTANCE_DIR, "failures.db"),
    }

    SQLALCHEMY_TRACK_MODIFICATIONS = False
