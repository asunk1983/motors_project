from flask import Flask, render_template

from config import Config
from extensions import db


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    db.init_app(app)

    # --- Регистрация модулей ---
    # Каждый модуль (blueprint) полностью самодостаточен: свои модели,
    # свои роуты, свои шаблоны. Общее — только фронтенд (base.html) и
    # то, что оба крутятся в одном Flask-процессе.

    from failures.routes import failures_bp
    app.register_blueprint(failures_bp, url_prefix="/failures")

    # Когда будете переносить существующий проект паспортов сюда —
    # оформите его так же в виде blueprint'а и раскомментируйте:
    # from passports.routes import passports_bp
    # app.register_blueprint(passports_bp, url_prefix="/passports")

    with app.app_context():
        db.create_all()  # создаст таблицы во всех бинд-базах, включая failures

    @app.route("/")
    def index():
        return render_template("index.html")

    return app


if __name__ == "__main__":
    app = create_app()
    app.run(debug=True)
